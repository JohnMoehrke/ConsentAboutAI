# Consent about AI - John Moehrke Consent About AI v0.2.0

## Resource Profile: Consent about AI 

**Usages:**

* Examples for this Profile: [Consent/AllAiProvisions](Consent-AllAiProvisions.md), [Consent/AllowCDS](Consent-AllowCDS.md), [Consent/AllowMLtraining](Consent-AllowMLtraining.md), [Consent/AllowMLtrainingOnDeIdentifiedData](Consent-AllowMLtrainingOnDeIdentifiedData.md)... Show 7 more, [Consent/AllowPaymentDS](Consent-AllowPaymentDS.md), [Consent/AllowSpecificAIforSpecificPurpose](Consent-AllowSpecificAIforSpecificPurpose.md), [Consent/DenyCDS](Consent-DenyCDS.md), [Consent/DenyMLtraining](Consent-DenyMLtraining.md), [Consent/DenyPaymentDS](Consent-DenyPaymentDS.md), [Consent/DenySpecificAIforSpecificPurpose](Consent-DenySpecificAIforSpecificPurpose.md) and [Consent/ThreeLevelsDeep](Consent-ThreeLevelsDeep.md)
* CapabilityStatements using this Profile: [Access Control Actor CapabilityStatement](CapabilityStatement-AccessControlCapability.md) and [AI-Consent Author Actor CapabilityStatement](CapabilityStatement-AiConsentAuthorCapability.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/johnmoehrke.ConsentAboutAI.example|current/StructureDefinition/StructureDefinition-ai-consent.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-ai-consent.csv), [Excel](../StructureDefinition-ai-consent.xlsx), [Schematron](../StructureDefinition-ai-consent.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ai-consent",
  "extension" : [{
    "extension" : [{
      "url" : "code",
      "valueCode" : "SHALL:populate"
    },
    {
      "url" : "actor",
      "valueCanonical" : "http://johnmoehrke.github.io/ConsentAboutAI/ActorDefinition/AiConsentAuthor"
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
  },
  {
    "extension" : [{
      "url" : "code",
      "valueCode" : "SHALL:process"
    },
    {
      "url" : "actor",
      "valueCanonical" : "http://johnmoehrke.github.io/ConsentAboutAI/ActorDefinition/AccessControl"
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
  }],
  "url" : "http://johnmoehrke.github.io/ConsentAboutAI/StructureDefinition/ai-consent",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:1.3.6.1.4.1.66281.2.1.42.3"
  }],
  "version" : "0.2.0",
  "name" : "AiConsent",
  "title" : "Consent about AI",
  "status" : "draft",
  "date" : "2026-11-17T11:58:11-06:00",
  "publisher" : "John Moehrke (Moehrke Research LLC)",
  "contact" : [{
    "name" : "John Moehrke (Moehrke Research LLC)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://healthcaresecprivacy.blogspot.com"
    },
    {
      "system" : "email",
      "value" : "JohnMoehrke@gmail.com"
    }]
  }],
  "description" : "A Consent profile for recording a patient's decision to permit or deny use of AI.\n\n- The scope is patient-privacy.\n- The patient and dateTime are required.\n- The root provision carries the type (permit or deny) and the applicable PurposeOfUse code(s), such as MLTRAINING or TREATDS.\n- sub provisions may be AI specific\n- When a specific AI system or model is permitted or denied, the provision.actor.reference identifies that AI as a Device.\n- A provision may carry a consent-provision-limit modifierExtension, such as an obligation to de-identify.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Consent",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Consent",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Consent",
      "path" : "Consent"
    },
    {
      "id" : "Consent.scope",
      "path" : "Consent.scope",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
          "code" : "patient-privacy"
        }]
      }
    },
    {
      "id" : "Consent.patient",
      "path" : "Consent.patient",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Consent.dateTime",
      "path" : "Consent.dateTime",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Consent.provision",
      "path" : "Consent.provision",
      "min" : 1,
      "constraint" : [{
        "key" : "aic-ai-device",
        "severity" : "error",
        "human" : "When the provision purpose includes an AI purpose of use, an actor that is a Device must conform to the AI Device profile. No purpose, or non-AI purposes, place no constraint on the actor.",
        "expression" : "purpose.where(memberOf('http://johnmoehrke.github.io/ConsentAboutAI/ValueSet/ai-purposeofuse')).exists() implies actor.reference.resolve().ofType(Device).all(conformsTo('http://hl7.org/fhir/uv/aitransparency/StructureDefinition/AI-Device'))",
        "source" : "http://johnmoehrke.github.io/ConsentAboutAI/StructureDefinition/ai-consent"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Consent.provision.modifierExtension",
      "path" : "Consent.provision.modifierExtension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Consent.provision.modifierExtension:limit",
      "path" : "Consent.provision.modifierExtension",
      "sliceName" : "limit",
      "short" : "Limits, such as an obligation to de-identify, placed on a permit provision",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/consent-provision-limit"]
      }]
    },
    {
      "id" : "Consent.provision.type",
      "path" : "Consent.provision.type",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Consent.provision.period",
      "path" : "Consent.provision.period",
      "mustSupport" : true
    },
    {
      "id" : "Consent.provision.actor",
      "path" : "Consent.provision.actor",
      "comment" : "When a specific AI system or model is permitted or denied, the actor.reference SHALL identify that AI as a Device, and all data access by the AI SHALL be attributed to that Device.",
      "mustSupport" : true
    },
    {
      "id" : "Consent.provision.purpose",
      "path" : "Consent.provision.purpose",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this"
        }],
        "rules" : "open"
      },
      "short" : "PurposeOfUse code(s) addressed, such as MLTRAINING or TREATDS",
      "comment" : "The consent is an AiConsent if it carries at least one purposeOfUse AI relevant code. In R4 the root provision holds all possible purposeOfUse.",
      "min" : 1
    },
    {
      "id" : "Consent.provision.purpose:aiPurposeOfUse",
      "path" : "Consent.provision.purpose",
      "sliceName" : "aiPurposeOfUse",
      "min" : 1,
      "max" : "*",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://johnmoehrke.github.io/ConsentAboutAI/ValueSet/ai-purposeofuse"
      }
    },
    {
      "id" : "Consent.provision.provision",
      "path" : "Consent.provision.provision",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "purpose"
        }],
        "rules" : "open"
      },
      "constraint" : [{
        "key" : "aic-ai-device",
        "severity" : "error",
        "human" : "When the provision purpose includes an AI purpose of use, an actor that is a Device must conform to the AI Device profile. No purpose, or non-AI purposes, place no constraint on the actor.",
        "expression" : "purpose.where(memberOf('http://johnmoehrke.github.io/ConsentAboutAI/ValueSet/ai-purposeofuse')).exists() implies actor.reference.resolve().ofType(Device).all(conformsTo('http://hl7.org/fhir/uv/aitransparency/StructureDefinition/AI-Device'))",
        "source" : "http://johnmoehrke.github.io/ConsentAboutAI/StructureDefinition/ai-consent"
      }]
    },
    {
      "id" : "Consent.provision.provision:aiProvision",
      "path" : "Consent.provision.provision",
      "sliceName" : "aiProvision",
      "short" : "Provision addressing an AI purpose of use",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "Consent.provision.provision:aiProvision.modifierExtension",
      "path" : "Consent.provision.provision.modifierExtension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Consent.provision.provision:aiProvision.modifierExtension:limit",
      "path" : "Consent.provision.provision.modifierExtension",
      "sliceName" : "limit",
      "short" : "Limits, such as an obligation to de-identify, placed on a permit provision",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/consent-provision-limit"]
      }]
    },
    {
      "id" : "Consent.provision.provision:aiProvision.type",
      "path" : "Consent.provision.provision.type",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Consent.provision.provision:aiProvision.actor",
      "path" : "Consent.provision.provision.actor",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "reference.resolve()"
        }],
        "rules" : "open"
      }
    },
    {
      "id" : "Consent.provision.provision:aiProvision.actor:aiDevice",
      "path" : "Consent.provision.provision.actor",
      "sliceName" : "aiDevice",
      "short" : "The specific AI system or model being permitted or denied",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Consent.provision.provision:aiProvision.actor:aiDevice.reference",
      "path" : "Consent.provision.provision.actor.reference",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/uv/aitransparency/StructureDefinition/AI-Device"]
      }]
    },
    {
      "id" : "Consent.provision.provision:aiProvision.purpose",
      "path" : "Consent.provision.provision.purpose",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this"
        }],
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "Consent.provision.provision:aiProvision.purpose:aiPurposeOfUse",
      "path" : "Consent.provision.provision.purpose",
      "sliceName" : "aiPurposeOfUse",
      "min" : 1,
      "max" : "*",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://johnmoehrke.github.io/ConsentAboutAI/ValueSet/ai-purposeofuse"
      }
    },
    {
      "id" : "Consent.provision.provision:aiProvision.provision",
      "path" : "Consent.provision.provision.provision",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "purpose"
        }],
        "rules" : "open"
      },
      "constraint" : [{
        "key" : "aic-ai-device",
        "severity" : "error",
        "human" : "When the provision purpose includes an AI purpose of use, an actor that is a Device must conform to the AI Device profile. No purpose, or non-AI purposes, place no constraint on the actor.",
        "expression" : "purpose.where(memberOf('http://johnmoehrke.github.io/ConsentAboutAI/ValueSet/ai-purposeofuse')).exists() implies actor.reference.resolve().ofType(Device).all(conformsTo('http://hl7.org/fhir/uv/aitransparency/StructureDefinition/AI-Device'))",
        "source" : "http://johnmoehrke.github.io/ConsentAboutAI/StructureDefinition/ai-consent"
      }]
    },
    {
      "id" : "Consent.provision.provision:aiProvision.provision:aiProvision",
      "path" : "Consent.provision.provision.provision",
      "sliceName" : "aiProvision",
      "short" : "Provision addressing an AI purpose of use",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "Consent.provision.provision:aiProvision.provision:aiProvision.modifierExtension",
      "path" : "Consent.provision.provision.provision.modifierExtension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Consent.provision.provision:aiProvision.provision:aiProvision.modifierExtension:limit",
      "path" : "Consent.provision.provision.provision.modifierExtension",
      "sliceName" : "limit",
      "short" : "Limits, such as an obligation to de-identify, placed on a permit provision",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/consent-provision-limit"]
      }]
    },
    {
      "id" : "Consent.provision.provision:aiProvision.provision:aiProvision.type",
      "path" : "Consent.provision.provision.provision.type",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Consent.provision.provision:aiProvision.provision:aiProvision.actor",
      "path" : "Consent.provision.provision.provision.actor",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "reference.resolve()"
        }],
        "rules" : "open"
      }
    },
    {
      "id" : "Consent.provision.provision:aiProvision.provision:aiProvision.actor:aiDevice",
      "path" : "Consent.provision.provision.provision.actor",
      "sliceName" : "aiDevice",
      "short" : "The specific AI system or model being permitted or denied",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Consent.provision.provision:aiProvision.provision:aiProvision.actor:aiDevice.reference",
      "path" : "Consent.provision.provision.provision.actor.reference",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/uv/aitransparency/StructureDefinition/AI-Device"]
      }]
    },
    {
      "id" : "Consent.provision.provision:aiProvision.provision:aiProvision.purpose",
      "path" : "Consent.provision.provision.provision.purpose",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this"
        }],
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "Consent.provision.provision:aiProvision.provision:aiProvision.purpose:aiPurposeOfUse",
      "path" : "Consent.provision.provision.provision.purpose",
      "sliceName" : "aiPurposeOfUse",
      "min" : 1,
      "max" : "*",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://johnmoehrke.github.io/ConsentAboutAI/ValueSet/ai-purposeofuse"
      }
    }]
  }
}

```
