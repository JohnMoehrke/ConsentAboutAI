# AI-Consent Author - JSON Representation - John Moehrke Consent About AI v0.2.0

## : AI-Consent Author

[Raw json](ActorDefinition-AiConsentAuthor.json) | [Download](ActorDefinition-AiConsentAuthor.json)

