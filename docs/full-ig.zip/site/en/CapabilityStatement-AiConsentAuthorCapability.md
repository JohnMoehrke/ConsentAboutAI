# AI-Consent Author Actor CapabilityStatement - John Moehrke Consent About AI v0.2.0

## CapabilityStatement: AI-Consent Author Actor CapabilityStatement 

 [Raw OpenAPI-Swagger Definition file](../AiConsentAuthorCapability.openapi.json) | [Download](../AiConsentAuthorCapability.openapi.json) 



## Resource Content

```json
{
  "resourceType" : "CapabilityStatement",
  "id" : "AiConsentAuthorCapability",
  "url" : "http://johnmoehrke.github.io/ConsentAboutAI/CapabilityStatement/AiConsentAuthorCapability",
  "version" : "0.2.0",
  "name" : "AiConsentAuthorCapability",
  "title" : "AI-Consent Author Actor CapabilityStatement",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-11-16",
  "publisher" : "John Moehrke (Moehrke Research LLC)",
  "contact" : [{
    "name" : "John Moehrke (Moehrke Research LLC)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://healthcaresecprivacy.blogspot.com"
    },
    {
      "system" : "email",
      "value" : "JohnMoehrke@gmail.com"
    }]
  }],
  "description" : "The AI-Consent Author actor records the patient's decisions about AI as Consents conforming to the Consent about AI profile.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "kind" : "requirements",
  "fhirVersion" : "4.0.1",
  "format" : ["json", "xml"],
  "rest" : [{
    "mode" : "client",
    "documentation" : "The AI-Consent Author actor creates and updates Consents conforming to the Consent about AI profile.",
    "resource" : [{
      "type" : "Consent",
      "supportedProfile" : ["http://johnmoehrke.github.io/ConsentAboutAI/StructureDefinition/ai-consent"],
      "interaction" : [{
        "code" : "create"
      },
      {
        "code" : "update"
      },
      {
        "code" : "read"
      }]
    }]
  }]
}

```
