# AI-Consent Author - TTL Representation - John Moehrke Consent About AI v0.2.0

## : AI-Consent Author

[Raw ttl](ActorDefinition-AiConsentAuthor.ttl) | [Download](ActorDefinition-AiConsentAuthor.ttl)

