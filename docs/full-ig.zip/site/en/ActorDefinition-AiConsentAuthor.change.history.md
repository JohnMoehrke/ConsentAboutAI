#  - John Moehrke Consent About AI v0.2.0

## ActorDefinition: AI-Consent Author - Change History

History of changes for AiConsentAuthor actordefinition.

