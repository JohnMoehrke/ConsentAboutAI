# Data Requester - TTL Representation - John Moehrke Consent About AI v0.2.0

## : Data Requester

[Raw ttl](ActorDefinition-DataRequester.ttl) | [Download](ActorDefinition-DataRequester.ttl)

