# Access Control Actor CapabilityStatement - John Moehrke Consent About AI v0.2.0

## CapabilityStatement: Access Control Actor CapabilityStatement 

 [Raw OpenAPI-Swagger Definition file](../AccessControlCapability.openapi.json) | [Download](../AccessControlCapability.openapi.json) 



## Resource Content

```json
{
  "resourceType" : "CapabilityStatement",
  "id" : "AccessControlCapability",
  "url" : "http://johnmoehrke.github.io/ConsentAboutAI/CapabilityStatement/AccessControlCapability",
  "version" : "0.2.0",
  "name" : "AccessControlCapability",
  "title" : "Access Control Actor CapabilityStatement",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-11-16",
  "publisher" : "John Moehrke (Moehrke Research LLC)",
  "contact" : [{
    "name" : "John Moehrke (Moehrke Research LLC)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://healthcaresecprivacy.blogspot.com"
    },
    {
      "system" : "email",
      "value" : "JohnMoehrke@gmail.com"
    }]
  }],
  "description" : "The Access Control actor reads and evaluates Consents conforming to the Consent about AI profile in order to enforce them. It enforces the provisions, including the PurposeOfUse declared by the Data Requester or AI Agent, any specific AI Device identified, and any limits placed upon a permit.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "kind" : "requirements",
  "fhirVersion" : "4.0.1",
  "format" : ["json", "xml"],
  "rest" : [{
    "mode" : "client",
    "documentation" : "The Access Control actor retrieves the Consents applicable to the patient and the requesting system.",
    "resource" : [{
      "type" : "Consent",
      "supportedProfile" : ["http://johnmoehrke.github.io/ConsentAboutAI/StructureDefinition/ai-consent"],
      "interaction" : [{
        "code" : "read"
      },
      {
        "code" : "search-type"
      }]
    }]
  }]
}

```
