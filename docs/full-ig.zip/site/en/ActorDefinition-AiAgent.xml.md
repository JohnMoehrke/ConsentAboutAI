# AI Agent - XML Representation - John Moehrke Consent About AI v0.2.0

## : AI Agent

[Raw xml](ActorDefinition-AiAgent.xml) | [Download](ActorDefinition-AiAgent.xml)

