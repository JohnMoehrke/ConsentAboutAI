# Data Requester Actor CapabilityStatement - John Moehrke Consent About AI v0.2.0

## CapabilityStatement: Data Requester Actor CapabilityStatement 

 [Raw OpenAPI-Swagger Definition file](../DataRequesterCapability.openapi.json) | [Download](../DataRequesterCapability.openapi.json) 



## Resource Content

```json
{
  "resourceType" : "CapabilityStatement",
  "id" : "DataRequesterCapability",
  "url" : "http://johnmoehrke.github.io/ConsentAboutAI/CapabilityStatement/DataRequesterCapability",
  "version" : "0.2.0",
  "name" : "DataRequesterCapability",
  "title" : "Data Requester Actor CapabilityStatement",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-11-16",
  "publisher" : "John Moehrke (Moehrke Research LLC)",
  "contact" : [{
    "name" : "John Moehrke (Moehrke Research LLC)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://healthcaresecprivacy.blogspot.com"
    },
    {
      "system" : "email",
      "value" : "JohnMoehrke@gmail.com"
    }]
  }],
  "description" : "The Data Requester actor is the AI system that directly requests and accesses data. The kinds of data accessed are not constrained by this guide. When accessing data, it declares the applicable PurposeOfUse code, and its accesses are attributed to the AI-Device describing the AI.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "kind" : "requirements",
  "fhirVersion" : "4.0.1",
  "format" : ["json", "xml"],
  "rest" : [{
    "mode" : "client",
    "documentation" : "The Data Requester actor accesses data of any kind, declaring the applicable PurposeOfUse code with each access, with the access attributed to the AI-Device describing the AI."
  }]
}

```
