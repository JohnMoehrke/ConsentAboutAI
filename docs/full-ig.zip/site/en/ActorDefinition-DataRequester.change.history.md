#  - John Moehrke Consent About AI v0.2.0

## ActorDefinition: Data Requester - Change History

History of changes for DataRequester actordefinition.

