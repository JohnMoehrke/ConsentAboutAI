# AI Agent - John Moehrke Consent About AI v0.2.0

## ActorDefinition: AI Agent 

### Test Plans

**No test plans are currently available for the AiAgent ActorDefinition.**

### Test Scripts

**No test scripts are currently available for the AiAgent ActorDefinition.**

