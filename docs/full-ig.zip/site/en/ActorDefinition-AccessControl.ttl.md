# Access Control - TTL Representation - John Moehrke Consent About AI v0.2.0

## : Access Control

[Raw ttl](ActorDefinition-AccessControl.ttl) | [Download](ActorDefinition-AccessControl.ttl)

