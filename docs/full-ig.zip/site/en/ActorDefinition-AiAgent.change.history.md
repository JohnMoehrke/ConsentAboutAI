#  - John Moehrke Consent About AI v0.2.0

## ActorDefinition: AI Agent - Change History

History of changes for AiAgent actordefinition.

