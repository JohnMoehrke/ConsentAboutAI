# Data Requester - JSON Representation - John Moehrke Consent About AI v0.2.0

## : Data Requester

[Raw json](ActorDefinition-DataRequester.json) | [Download](ActorDefinition-DataRequester.json)

