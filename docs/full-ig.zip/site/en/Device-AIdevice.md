# AI Device - John Moehrke Consent About AI v0.2.0

## Example Device: AI Device

Profile: [AI Device](https://build.fhir.org/ig/HL7/aitransparency-ig/StructureDefinition-AI-Device.html)

**identifier**: `http://example.org/ehr/client-ids`/goodhealth

**manufacturer**: Acme Devices, Inc

**type**: Artificial intelligence device

### Versions

| | |
| :--- | :--- |
| - | **Value** |
| * | 10.23-23423 |

**contact**: [http://example.org](http://example.org)



## Resource Content

```json
{
  "resourceType" : "Device",
  "id" : "AIdevice",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/aitransparency/StructureDefinition/AI-Device"]
  },
  "identifier" : [{
    "system" : "http://example.org/ehr/client-ids",
    "value" : "goodhealth"
  }],
  "manufacturer" : "Acme Devices, Inc",
  "type" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/AIdeviceTypeCS",
      "code" : "Artificial-Intelligence"
    }],
    "text" : "Artificial intelligence device"
  },
  "version" : [{
    "value" : "10.23-23423"
  }],
  "contact" : [{
    "system" : "url",
    "value" : "http://example.org"
  }]
}

```
