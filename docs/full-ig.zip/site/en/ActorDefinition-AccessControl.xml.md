# Access Control - XML Representation - John Moehrke Consent About AI v0.2.0

## : Access Control

[Raw xml](ActorDefinition-AccessControl.xml) | [Download](ActorDefinition-AccessControl.xml)

