# AI-Consent Author - John Moehrke Consent About AI v0.2.0

## ActorDefinition: AI-Consent Author 

### Test Plans

**No test plans are currently available for the AiConsentAuthor ActorDefinition.**

### Test Scripts

**No test scripts are currently available for the AiConsentAuthor ActorDefinition.**

