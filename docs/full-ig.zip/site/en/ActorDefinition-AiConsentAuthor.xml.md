# AI-Consent Author - XML Representation - John Moehrke Consent About AI v0.2.0

## : AI-Consent Author

[Raw xml](ActorDefinition-AiConsentAuthor.xml) | [Download](ActorDefinition-AiConsentAuthor.xml)

