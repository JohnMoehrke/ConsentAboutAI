# AI Agent Actor CapabilityStatement - John Moehrke Consent About AI v0.2.0

## CapabilityStatement: AI Agent Actor CapabilityStatement 

 [Raw OpenAPI-Swagger Definition file](../AiAgentCapability.openapi.json) | [Download](../AiAgentCapability.openapi.json) 



## Resource Content

```json
{
  "resourceType" : "CapabilityStatement",
  "id" : "AiAgentCapability",
  "url" : "http://johnmoehrke.github.io/ConsentAboutAI/CapabilityStatement/AiAgentCapability",
  "version" : "0.2.0",
  "name" : "AiAgentCapability",
  "title" : "AI Agent Actor CapabilityStatement",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-11-16",
  "publisher" : "John Moehrke (Moehrke Research LLC)",
  "contact" : [{
    "name" : "John Moehrke (Moehrke Research LLC)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://healthcaresecprivacy.blogspot.com"
    },
    {
      "system" : "email",
      "value" : "JohnMoehrke@gmail.com"
    }]
  }],
  "description" : "The AI Agent actor is the agent (gateway) that accesses data on behalf of an AI, feeding that data to the AI. The kinds of data accessed are not constrained by this guide. When accessing data, it declares the applicable PurposeOfUse code of the AI it is feeding, and attributes those accesses to the AI-Device describing the AI.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "kind" : "requirements",
  "fhirVersion" : "4.0.1",
  "format" : ["json", "xml"],
  "rest" : [{
    "mode" : "client",
    "documentation" : "The AI Agent actor accesses data of any kind on behalf of an AI, declaring the applicable PurposeOfUse code with each access, with the access attributed to the AI-Device describing the AI being fed."
  }]
}

```
