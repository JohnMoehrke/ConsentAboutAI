# AI Agent - TTL Representation - John Moehrke Consent About AI v0.2.0

## : AI Agent

[Raw ttl](ActorDefinition-AiAgent.ttl) | [Download](ActorDefinition-AiAgent.ttl)

