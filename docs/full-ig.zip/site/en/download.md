# Downloads and Analysis - John Moehrke Consent About AI v0.2.0

## Downloads and Analysis

You can also download:

* [this entire guide](full-ig.zip),
* the definition resources in [json](../definitions.json.zip), [xml](../definitions.xml.zip), [ttl](../definitions.ttl.zip), or [csv](../csvs.zip) format, or
* the example resources in [json](../examples.json.zip), [xml](../examples.xml.zip) or [ttl](../examples.ttl.zip) format.

The source code for this Implementation Guide can be found on [John Moehrke ConsentAboutAI Github Repo](https://github.com/JohnMoehrke/ConsentAboutAI).

### Publisher Analysis

#### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (johnmoehrke.ConsentAboutAI.example.r4)](../package.r4.tgz) and [R4B (johnmoehrke.ConsentAboutAI.example.r4b)](../package.r4b.tgz) are available.

#### Dependency Table






#### Globals Table

*There are no Global profiles defined*

#### IP Statements

This publication includes IP covered under the following statements.

* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/5.1.0/CodeSystem-v3-loinc.html): [Consent/AllAiProvisions](Consent-AllAiProvisions.md), [Consent/AllowCDS](Consent-AllowCDS.md)... Show 9 more, [Consent/AllowMLtraining](Consent-AllowMLtraining.md), [Consent/AllowMLtrainingOnDeIdentifiedData](Consent-AllowMLtrainingOnDeIdentifiedData.md), [Consent/AllowPaymentDS](Consent-AllowPaymentDS.md), [Consent/AllowSpecificAIforSpecificPurpose](Consent-AllowSpecificAIforSpecificPurpose.md), [Consent/DenyCDS](Consent-DenyCDS.md), [Consent/DenyMLtraining](Consent-DenyMLtraining.md), [Consent/DenyPaymentDS](Consent-DenyPaymentDS.md), [Consent/DenySpecificAIforSpecificPurpose](Consent-DenySpecificAIforSpecificPurpose.md) and [Consent/ThreeLevelsDeep](Consent-ThreeLevelsDeep.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [Consent Scope Codes](http://terminology.hl7.org/7.5.0/CodeSystem-consentscope.html): [AiConsent](StructureDefinition-ai-consent.md), [Consent/AllAiProvisions](Consent-AllAiProvisions.md)... Show 10 more, [Consent/AllowCDS](Consent-AllowCDS.md), [Consent/AllowMLtraining](Consent-AllowMLtraining.md), [Consent/AllowMLtrainingOnDeIdentifiedData](Consent-AllowMLtrainingOnDeIdentifiedData.md), [Consent/AllowPaymentDS](Consent-AllowPaymentDS.md), [Consent/AllowSpecificAIforSpecificPurpose](Consent-AllowSpecificAIforSpecificPurpose.md), [Consent/DenyCDS](Consent-DenyCDS.md), [Consent/DenyMLtraining](Consent-DenyMLtraining.md), [Consent/DenyPaymentDS](Consent-DenyPaymentDS.md), [Consent/DenySpecificAIforSpecificPurpose](Consent-DenySpecificAIforSpecificPurpose.md) and [Consent/ThreeLevelsDeep](Consent-ThreeLevelsDeep.md)
* [ActCode](http://terminology.hl7.org/7.5.0/CodeSystem-v3-ActCode.html): [Consent/AllAiProvisions](Consent-AllAiProvisions.md), [Consent/AllowCDS](Consent-AllowCDS.md)... Show 9 more, [Consent/AllowMLtraining](Consent-AllowMLtraining.md), [Consent/AllowMLtrainingOnDeIdentifiedData](Consent-AllowMLtrainingOnDeIdentifiedData.md), [Consent/AllowPaymentDS](Consent-AllowPaymentDS.md), [Consent/AllowSpecificAIforSpecificPurpose](Consent-AllowSpecificAIforSpecificPurpose.md), [Consent/DenyCDS](Consent-DenyCDS.md), [Consent/DenyMLtraining](Consent-DenyMLtraining.md), [Consent/DenyPaymentDS](Consent-DenyPaymentDS.md), [Consent/DenySpecificAIforSpecificPurpose](Consent-DenySpecificAIforSpecificPurpose.md) and [Consent/ThreeLevelsDeep](Consent-ThreeLevelsDeep.md)
* [ActReason](http://terminology.hl7.org/7.5.0/CodeSystem-v3-ActReason.html): [AiConsent](StructureDefinition-ai-consent.md), [AiPurposeOfUse](ValueSet-ai-purposeofuse.md)... Show 12 more, [Consent/AllAiProvisions](Consent-AllAiProvisions.md), [Consent/AllowCDS](Consent-AllowCDS.md), [Consent/AllowMLtraining](Consent-AllowMLtraining.md), [Consent/AllowMLtrainingOnDeIdentifiedData](Consent-AllowMLtrainingOnDeIdentifiedData.md), [Consent/AllowPaymentDS](Consent-AllowPaymentDS.md), [Consent/AllowSpecificAIforSpecificPurpose](Consent-AllowSpecificAIforSpecificPurpose.md), [Consent/DenyCDS](Consent-DenyCDS.md), [Consent/DenyMLtraining](Consent-DenyMLtraining.md), [Consent/DenyPaymentDS](Consent-DenyPaymentDS.md), [Consent/DenySpecificAIforSpecificPurpose](Consent-DenySpecificAIforSpecificPurpose.md), [Consent/ThreeLevelsDeep](Consent-ThreeLevelsDeep.md) and [Patient/ex-patient](Patient-ex-patient.md)
* [Confidentiality](http://terminology.hl7.org/7.5.0/CodeSystem-v3-Confidentiality.html): [Consent/AllAiProvisions](Consent-AllAiProvisions.md) and [Consent/ThreeLevelsDeep](Consent-ThreeLevelsDeep.md)
* [ParticipationFunction](http://terminology.hl7.org/7.5.0/CodeSystem-v3-ParticipationFunction.html): [Consent/AllAiProvisions](Consent-AllAiProvisions.md)


