# Data Requester - John Moehrke Consent About AI v0.2.0

## ActorDefinition: Data Requester 

