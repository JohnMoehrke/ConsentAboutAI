# Access Control - John Moehrke Consent About AI v0.2.0

## ActorDefinition: Access Control 

### Test Plans

**No test plans are currently available for the AccessControl ActorDefinition.**

### Test Scripts

**No test scripts are currently available for the AccessControl ActorDefinition.**

