# Access Control - JSON Representation - John Moehrke Consent About AI v0.2.0

## : Access Control

[Raw json](ActorDefinition-AccessControl.json) | [Download](ActorDefinition-AccessControl.json)

