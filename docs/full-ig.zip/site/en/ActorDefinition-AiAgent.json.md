# AI Agent - JSON Representation - John Moehrke Consent About AI v0.2.0

## : AI Agent

[Raw json](ActorDefinition-AiAgent.json) | [Download](ActorDefinition-AiAgent.json)

