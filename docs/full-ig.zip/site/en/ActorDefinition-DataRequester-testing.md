# Data Requester - John Moehrke Consent About AI v0.2.0

## ActorDefinition: Data Requester 

### Test Plans

**No test plans are currently available for the DataRequester ActorDefinition.**

### Test Scripts

**No test scripts are currently available for the DataRequester ActorDefinition.**

