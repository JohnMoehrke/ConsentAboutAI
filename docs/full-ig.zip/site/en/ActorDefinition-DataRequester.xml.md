# Data Requester - XML Representation - John Moehrke Consent About AI v0.2.0

## : Data Requester

[Raw xml](ActorDefinition-DataRequester.xml) | [Download](ActorDefinition-DataRequester.xml)

