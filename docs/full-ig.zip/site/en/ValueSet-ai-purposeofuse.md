# AI Purposes Of Use - John Moehrke Consent About AI v0.2.0

## ValueSet: AI Purposes Of Use 

 **References** 

* [Consent about AI](StructureDefinition-ai-consent.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ai-purposeofuse",
  "url" : "http://johnmoehrke.github.io/ConsentAboutAI/ValueSet/ai-purposeofuse",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:1.3.6.1.4.1.66281.2.1.48.1"
  }],
  "version" : "0.2.0",
  "name" : "AiPurposeOfUse",
  "title" : "AI Purposes Of Use",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-11-17T11:58:11-06:00",
  "publisher" : "John Moehrke (Moehrke Research LLC)",
  "contact" : [{
    "name" : "John Moehrke (Moehrke Research LLC)",
    "telecom" : [{
      "system" : "url",
      "value" : "http://healthcaresecprivacy.blogspot.com"
    },
    {
      "system" : "email",
      "value" : "JohnMoehrke@gmail.com"
    }]
  }],
  "description" : "The PurposeOfUse codes for AI uses of data: machine learning training, clinical decision support, and payment decision support.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "version" : "4.0.0",
      "concept" : [{
        "code" : "MLTRAINING"
      },
      {
        "code" : "TREATDS"
      },
      {
        "code" : "PMTDS"
      }]
    }]
  }
}

```
