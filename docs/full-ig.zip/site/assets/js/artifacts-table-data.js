window.artifactsTableData = {
  "en": {
    "labels": {
      "type":        "Type",
      "category":    "Category",
      "useGrouping": "Use grouping",
      "clearAll":      "Clear all",
      "linkToSection": "Link to this section"
    },
    "groupDescriptions": {
      "-str-profile": "<p>These define constraints on FHIR resources for systems conforming to this implementation guide.</p>\n"
      ,"-ex-example": "<p>These are example instances that show what data produced and consumed by systems conforming with this implementation guide might look like.</p>\n"
    },
    "rows": [
      { "p":1, "gid":"-str-profile", "g":"Structures: Resource Profiles", "n":"Consent with use of the Limits extension", "i":"ConsentWithLimits", "t":"StructureDefinition", "u":"StructureDefinition-ConsentWithLimits.html", "r":"StructureDefinition/ConsentWithLimits", "d":"<p>Consent profile that includes the use of the consent-provision-limit extension to express limits on the use of data for ML training.</p>" },
      { "p":2, "gid":"-ex-example", "g":"Example: Example Instances", "n":"AI Device", "i":"AIdevice", "t":"Device", "u":"Device-AIdevice.html", "r":"Device/AIdevice", "d":"<p>A Device that indicates an AI system or model. This is not using the AI-Transparency profile in order to keep this IG simple.</p>" },
      { "p":2, "gid":"-ex-example", "g":"Example: Example Instances", "n":"Consent for Clinical Decision Support", "i":"AllowCDS", "t":"Consent", "u":"Consent-AllowCDS.html", "r":"Consent/AllowCDS", "d":"<p>Consent for using data for clinical decision support purposes.</p>" },
      { "p":2, "gid":"-ex-example", "g":"Example: Example Instances", "n":"Consent for Machine Learning Training", "i":"AllowMLtraining", "t":"Consent", "u":"Consent-AllowMLtraining.html", "r":"Consent/AllowMLtraining", "d":"<p>Consent for using data for machine learning training purposes.</p>" },
      { "p":2, "gid":"-ex-example", "g":"Example: Example Instances", "n":"Consent for Machine Learning Training on De-Identified Data", "i":"AllowMLtrainingOnDeIdentifiedData", "t":"Consent", "u":"Consent-AllowMLtrainingOnDeIdentifiedData.html", "r":"Consent/AllowMLtrainingOnDeIdentifiedData", "d":"<p>Consent for using de-identified data for machine learning training purposes.</p>" },
      { "p":2, "gid":"-ex-example", "g":"Example: Example Instances", "n":"Consent to allow specific AI for a specific purpose", "i":"AllowSpecificAIforSpecificPurpose", "t":"Consent", "u":"Consent-AllowSpecificAIforSpecificPurpose.html", "r":"Consent/AllowSpecificAIforSpecificPurpose", "d":"<p>Consent to allow the use of a specific AI device for a specific purpose.\nIn this case a Device is used to represent the specific AI system or model. In this case the purpose is for CDS use.</p>" },
      { "p":2, "gid":"-ex-example", "g":"Example: Example Instances", "n":"Consent to disallow Clinical Decision Support", "i":"DenyCDS", "t":"Consent", "u":"Consent-DenyCDS.html", "r":"Consent/DenyCDS", "d":"<p>Consent to disallow using data for clinical decision support purposes.</p>" },
      { "p":2, "gid":"-ex-example", "g":"Example: Example Instances", "n":"Consent to disallow Machine Learning Training", "i":"DenyMLtraining", "t":"Consent", "u":"Consent-DenyMLtraining.html", "r":"Consent/DenyMLtraining", "d":"<p>Consent to disallow using data for machine learning training purposes.</p>" },
      { "p":2, "gid":"-ex-example", "g":"Example: Example Instances", "n":"Consent with all kinds of Provisions", "i":"AllAiProvisions", "t":"Consent", "u":"Consent-AllAiProvisions.html", "r":"Consent/AllAiProvisions", "d":"<p>Consent that includes provisions using the various AI mechanisms along with normal TPO.</p>\n\n<p>This consent</p>\n<ol>\n  <li>permits the patient's care team to have full access</li>\n  <li>permits TPO purposes to have access to Normal data, but not sensitive data</li>\n  <li>permits ML training purposes to have access to Normal de-identified data, but not sensitive data</li>\n</ol>\n\n<p>Given that FHIR R4 Consent has only ONE root level provision, we need to extra deep nesting:</p>\n\n<p>Provisions</p>\n<ul>\n  <li>Permit all the purposes\n    <ul>\n      <li>deny ML training for sensitive data\n        <ul>\n          <li>permit ML training for de-identified data</li>\n        </ul>\n      </li>\n      <li>deny TPO – just so we can skip to a permit\n        <ul>\n          <li>permit TPO for normal confidentiality</li>\n          <li>permit TPO for the care team for sensitive data</li>\n        </ul>\n      </li>\n    </ul>\n  </li>\n</ul>" },
      { "p":2, "gid":"-ex-example", "g":"Example: Example Instances", "n":"The Patient example", "i":"ex-patient", "t":"Patient", "u":"Patient-ex-patient.html", "r":"Patient/ex-patient", "d":"<p>The patient example is a patient named John Jacob Jingleheimer Schmidt, who has a variety of names and identifiers. This example is used to demonstrate the use of multiple names, identifiers, and other patient attributes in FHIR. This is the patient giving consent for the use of their data for AI/ML training, with specific limits on the use of that data.</p>" }
    ]
  }
};
