# johnmoehrke.ConsentAboutAI.example#0.2.0: John Moehrke Consent About AI

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)
* [Downloads and Analysis](download.md)

## Resources

### Resource Profiles

* [Consent with use of the Limits extension](StructureDefinition-ConsentWithLimits.md)

### ImplementationGuides

* [John Moehrke Consent About AI](index.md)

### Examples

* [AllAiProvisions (Consent)](Consent-AllAiProvisions.md)
* [AllowCDS (Consent)](Consent-AllowCDS.md)
* [AllowMLtraining (Consent)](Consent-AllowMLtraining.md)
* [AllowMLtrainingOnDeIdentifiedData (Consent)](Consent-AllowMLtrainingOnDeIdentifiedData.md)
* [AllowSpecificAIforSpecificPurpose (Consent)](Consent-AllowSpecificAIforSpecificPurpose.md)
* [DenyCDS (Consent)](Consent-DenyCDS.md)
* [DenyMLtraining (Consent)](Consent-DenyMLtraining.md)
* [AIdevice (Device)](Device-AIdevice.md)
* [ex-patient (Patient)](Patient-ex-patient.md)
